package ticketbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ticketbooking.DAO.RegistrationRepository;
import ticketbooking.model.Registration;

@RestController
@CrossOrigin
public class RegistrationController {
	
	@Autowired
	RegistrationRepository registrationRepository;
		  

	 Registration reg1=new Registration(101,"Aiswarya","8798765786","Madurai","aiswarya@gmail.com","aishwarya123");
	 Registration reg2=new Registration(102,"Sinthu","7865467898","Chennai","sinthu@gmail.com","sinthu123");
	 Registration reg3=new Registration(103,"Divya","6754898765","Bangalore","divya@gmail.com","divya123");
			  	

		/*
		 * @PostMapping("/register") public void addRegistration(@RequestBody
		 * Registration reg) { registrationRepository.save(reg);
		 * 
		 * }
		 */
	
	
	

}
