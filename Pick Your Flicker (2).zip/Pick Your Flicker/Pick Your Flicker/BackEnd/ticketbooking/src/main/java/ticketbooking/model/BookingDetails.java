package ticketbooking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="bookingdetails")
public class BookingDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="bookingseq")
	@Column(name="bookingId")
	private int bookingId;
	
	@Column(name="movName")
	private String movName;
	
	@Column(name="Slot")
	private String slot;
	
	
	@Column(name="schedule")
	private String schedule;

	@Column(name="custName")
    private String custName;
	
	@Column(name="mobile")
    private String mobile;
	
	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BookingDetails(int bookingId, String movName, String slot, String schedule, String custName, String mobile,
			int no_of_tickets) {
		super();
		this.bookingId = bookingId;
		this.movName = movName;
		this.slot = slot;
		this.schedule = schedule;
		this.custName = custName;
		this.mobile = mobile;
		this.no_of_tickets = no_of_tickets;
	}
	public BookingDetails(String movName, String slot, String schedule, String custName, String mobile,
			int no_of_tickets) {
		super();
		this.movName = movName;
		this.slot = slot;
		this.schedule = schedule;
		this.custName = custName;
		this.mobile = mobile;
		this.no_of_tickets = no_of_tickets;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getMovName() {
		return movName;
	}

	public void setMovName(String movName) {
		this.movName = movName;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getNo_of_tickets() {
		return no_of_tickets;
	}

	public void setNo_of_tickets(int no_of_tickets) {
		this.no_of_tickets = no_of_tickets;
	}

	@Column(name="noOfTickets")
	private int no_of_tickets;

	@Override
	public String toString() {
		return "BookingDetails [bookingId=" + bookingId + ", movName=" + movName + ", slot=" + slot + ", schedule="
				+ schedule + ", custName=" + custName + ", mobile=" + mobile + ", no_of_tickets=" + no_of_tickets + "]";
	}

	
	

	
}
