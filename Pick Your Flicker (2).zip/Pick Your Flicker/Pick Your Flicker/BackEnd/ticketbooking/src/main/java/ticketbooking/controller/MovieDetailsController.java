package ticketbooking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ticketbooking.DAO.MovieDetailsRepository;
import ticketbooking.model.Moviedetails;

@RestController
@CrossOrigin
public class MovieDetailsController {

	@Autowired
	MovieDetailsRepository movieDetailsRepository;
	
	Moviedetails mov1=new Moviedetails(201,"Kaala","slot1(9 AM - 12 PM)","24/09/2021",200);
	Moviedetails mov2=new Moviedetails(202,"Kaala","slot2(2 PM - 5 PM)","24/09/2021",200);
	Moviedetails mov3=new Moviedetails(203,"Kaala","slot3(10 PM - 1 AM)","24/09/2021",200);
	Moviedetails mov4=new Moviedetails(204,"Kasada Thapara","slot1(9 AM - 12 PM)","25/09/2021",200);
	Moviedetails mov5=new Moviedetails(205,"Kasada Thapara","slot2(2 PM - 5 PM)","25/09/2021",200);
	Moviedetails mov6=new Moviedetails(206,"Kasada Thapara","slot3(10 PM - 1 AM)","25/09/2021",200);
	Moviedetails mov7=new Moviedetails(207,"Master","slot1(9 AM - 12 PM)","26/09/2021",200);
	Moviedetails mov8=new Moviedetails(208,"Master","slot2(2 PM - 5 PM)","26/09/2021",200);
	Moviedetails mov9=new Moviedetails(209,"Master","slot3(10 PM - 1 AM)","26/09/2021",100);

	/*
	 * @PostMapping("/addmovie") public void addMoviesDetails(@RequestBody
	 * Moviedetails mov) { movieDetailsRepository.save(mov); }
	 */
	@GetMapping("/moviesdetails")
    public List<Moviedetails> movielist()
    {
		List<Moviedetails> mlist=new ArrayList<>();
    	Iterable<Moviedetails> it=movieDetailsRepository.findAll();
    	it.forEach(moviedetails -> {
    		mlist.add(moviedetails);
    		
    	});
    	System.out.println("movie");
        System.out.println(mlist);
        System.out.println("result");
    	return mlist;
    }
}
