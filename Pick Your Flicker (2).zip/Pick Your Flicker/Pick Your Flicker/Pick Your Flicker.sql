--------------------------------------------------------
--  File created - Wednesday-September-29-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence HIBERNATE_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."HIBERNATE_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ID
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LOGMNR_EVOLVE_SEQ$
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."LOGMNR_EVOLVE_SEQ$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LOGMNR_SEQ$
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."LOGMNR_SEQ$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LOGMNR_UIDS$
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."LOGMNR_UIDS$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 100 NOCACHE  ORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MVIEW$_ADVSEQ_GENERIC
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."MVIEW$_ADVSEQ_GENERIC"  MINVALUE 1 MAXVALUE 4294967295 INCREMENT BY 1 START WITH 1 CACHE 50 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MVIEW$_ADVSEQ_ID
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."MVIEW$_ADVSEQ_ID"  MINVALUE 1 MAXVALUE 4294967295 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_EXCEPTIONS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_EXCEPTIONS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_FLAVORS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_FLAVORS_S"  MINVALUE -2147483647 MAXVALUE 2147483647 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_FLAVOR_NAME_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_FLAVOR_NAME_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_REFRESH_TEMPLATES_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_REFRESH_TEMPLATES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_REPPROP_KEY
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_REPPROP_KEY"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_RUNTIME_PARMS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_RUNTIME_PARMS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_OBJECTS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_TEMPLATE_OBJECTS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_PARMS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_TEMPLATE_PARMS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_REFGROUPS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_TEMPLATE_REFGROUPS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_SITES_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_TEMPLATE_SITES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMP_OUTPUT_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_TEMP_OUTPUT_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_USER_AUTHORIZATIONS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_USER_AUTHORIZATIONS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT$_USER_PARM_VALUES_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT$_USER_PARM_VALUES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REPCAT_LOG_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."REPCAT_LOG_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TEMPLATE$_TARGETS_S
--------------------------------------------------------

   CREATE SEQUENCE  "SYSTEM"."TEMPLATE$_TARGETS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Table BOOKINGDETAILS
--------------------------------------------------------

  CREATE TABLE "SYSTEM"."BOOKINGDETAILS" 
   (	"BOOKING_ID" NUMBER(10,0), 
	"CUST_NAME" VARCHAR2(255 CHAR), 
	"MOBILE" VARCHAR2(255 CHAR), 
	"MOV_NAME" VARCHAR2(255 CHAR), 
	"NO_OF_TICKETS" NUMBER(10,0), 
	"SCHEDULE" VARCHAR2(255 CHAR), 
	"SLOT" VARCHAR2(255 CHAR)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table MOVIEDETAILS
--------------------------------------------------------

  CREATE TABLE "SYSTEM"."MOVIEDETAILS" 
   (	"MOVIE_ID" NUMBER(10,0), 
	"COST" NUMBER(10,0), 
	"NAME" VARCHAR2(255 CHAR), 
	"SCHEDULE" VARCHAR2(255 CHAR), 
	"SLOT" VARCHAR2(255 CHAR)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table REGISTRATION
--------------------------------------------------------

  CREATE TABLE "SYSTEM"."REGISTRATION" 
   (	"CUSTOMER_ID" NUMBER(10,0), 
	"CUSTOMER_ADDRESS" VARCHAR2(255 CHAR), 
	"CUSTOMER_EMAIL" VARCHAR2(255 CHAR), 
	"CUSTOMER_MOBILE" VARCHAR2(255 CHAR), 
	"CUSTOMER_NAME" VARCHAR2(255 CHAR), 
	"CUSTOMER_PASSWORD" VARCHAR2(255 CHAR)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into SYSTEM.BOOKINGDETAILS
SET DEFINE OFF;
Insert into SYSTEM.BOOKINGDETAILS (BOOKING_ID,CUST_NAME,MOBILE,MOV_NAME,NO_OF_TICKETS,SCHEDULE,SLOT) values (1,'pavi','8787980987','Master',3,'26/09/2021','slot3(10 PM - 1 AM)');
REM INSERTING into SYSTEM.MOVIEDETAILS
SET DEFINE OFF;
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (1,200,'Kaala','24/09/2021','slot1(9 AM - 12 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (2,200,'Kaala','24/09/2021','slot2(2 PM - 5 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (3,200,'Kaala','24/09/2021','slot3(10 PM - 1 AM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (4,200,'Kasada Thapara','25/09/2021','slot1(9 AM - 12 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (5,200,'Kasada Thapara','25/09/2021','slot2(2 PM - 5 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (6,200,'Kasada Thapara','25/09/2021','slot3(10 PM - 1 AM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (7,200,'Master','26/09/2021','slot1(9 AM - 12 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (8,200,'Master','26/09/2021','slot2(2 PM - 5 PM)');
Insert into SYSTEM.MOVIEDETAILS (MOVIE_ID,COST,NAME,SCHEDULE,SLOT) values (9,200,'Master','26/09/2021','slot3(10 PM - 1 AM)');
REM INSERTING into SYSTEM.REGISTRATION
SET DEFINE OFF;
Insert into SYSTEM.REGISTRATION (CUSTOMER_ID,CUSTOMER_ADDRESS,CUSTOMER_EMAIL,CUSTOMER_MOBILE,CUSTOMER_NAME,CUSTOMER_PASSWORD) values (1,'madurai','sinthu123@gmail.com','8489762419','sinthu','sinthu1997');
Insert into SYSTEM.REGISTRATION (CUSTOMER_ID,CUSTOMER_ADDRESS,CUSTOMER_EMAIL,CUSTOMER_MOBILE,CUSTOMER_NAME,CUSTOMER_PASSWORD) values (2,'chennai','pavi123@gmail.com','8787980987','pavi','pavi1999');
