package ticketbooking.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ticketbooking.model.Moviedetails;

@Repository
public interface MovieDetailsRepository extends JpaRepository<Moviedetails, Integer>{

}
